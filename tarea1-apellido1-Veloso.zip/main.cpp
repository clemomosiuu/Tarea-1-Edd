#include <fstream>
#include <cstring>
#include <string>
#include <iostream>
#include <iomanip>
using namespace std;

//struct
struct Dato {
    unsigned int Id;      
    char Nombre[50];    
    char Fecha_Nacimiento[11]; 
    int Notas[3];      
    char Curso[7];      
    unsigned short VTR;   
};

int n_alumni = 0; 

//funcion 1
Dato * Leer_Archivo ( const string & nombre_archivo ) {
    //abrir archivo
    ifstream fin(nombre_archivo, ios::binary);

    if (!fin.is_open()){
        cout<< "No se pudo abrir el archivo" << endl;
        fin.close();    
        return nullptr;
    }
    cout<< "Archivo abierto correctamente" << endl;
    //leer n inicial
    unsigned int n = 0;
    fin.read(reinterpret_cast<char*>(&n), sizeof(unsigned int));
    cout << "Cantidad de estudiantes: " << n << endl;

    //reservamos memoria dinamica para n
    Dato* datos = new Dato[n];
    n_alumni = n; 
    //recorremos los struct cvon un for
    for (unsigned int i = 0; i<n ; i++){
        fin.read((char*)&datos[i].Id, sizeof(unsigned int)); //3
        fin.read(datos[i].Nombre, 50); //53
        fin.read(datos[i].Fecha_Nacimiento, 11); //64
        fin.ignore(3);  // padding //67
        fin.read((char*)datos[i].Notas, 3 * sizeof(int)); //79
        fin.read(datos[i].Curso, 7); //86
        fin.ignore(1); // padding //87
        fin.read((char*)&datos[i].VTR, sizeof(unsigned short)); //90
        fin.ignore(2); // padding //92
    }
    fin.close();
    return datos;  
}

//funcion 2
int Eliminar_Duplicados(Dato* datos, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; ) {
            if (datos[i].Id == datos[j].Id) {
                for (int k = j; k < n - 1; k++) {
                    datos[k] = datos[k + 1];
                }
                n--; 
            } else {
                j++;
            }
        }
    }
    return n; 
}

//funcion 3
void Agregar_Alumno ( Dato *& datos , Dato Alumno_nuevo ) {
    cout<<"Ingrese los datos del estudiante:"<<endl;

    //id

    unsigned int id;
    cout<<"ID ( Numero mayor a 1500): ";
    cin >> id;
    if (id<=1500){
        cout<<"Id no valido"<<endl;
        return;
    }
    cin.ignore(1000, '\n');

    //nombre

    char nombre[50];
    cout<<"Primer nombre y primer apellido: ";
    cin.getline(nombre,50);

    //fecha

    char fecha[11];
    cout<<"Fecha de nacimiento (formato YYYY/MM/DD): ";
    cin.getline(fecha,11);

    //3 notas

    int n1,n2,n3;
    cout<<"Notas de las 3 evaluaciones (separadas por espacio): ";
    cin >> n1 >> n2 >> n3;
    cin.ignore(1000, '\n');

    //Curso

    char curso[7];
    cout<<"Sigla del curso (ejemplo: INF134): ";
    cin.getline(curso,7);

    //Veces tomado ramo

    unsigned int vtr;
    cout<<"VTR (1 -3): ";
    cin >> vtr;

    //2fa

    for (unsigned int i = 0; i < n_alumni; ++i) {
        if (datos[i].Id == id && strcmp(curso, datos[i].Curso) == 0) {
            cout << "Alumno ya ingresado en ese curso.";
            return;
        }
    }

    Alumno_nuevo.Id = id;
    strncpy(Alumno_nuevo.Nombre, nombre, 49); Alumno_nuevo.Nombre[49] = '\0';
    strncpy(Alumno_nuevo.Fecha_Nacimiento, fecha, 10); Alumno_nuevo.Fecha_Nacimiento[10] = '\0';
    Alumno_nuevo.Notas[0] = n1; Alumno_nuevo.Notas[1] = n2; Alumno_nuevo.Notas[2] = n3;
    strncpy(Alumno_nuevo.Curso, curso, 6); Alumno_nuevo.Curso[6] = '\0';
    Alumno_nuevo.VTR = vtr;

    Dato* crec = new Dato[n_alumni + 1];
    for (unsigned int i = 0; i < n_alumni; ++i) crec[i] = datos[i];
    crec[n_alumni] = Alumno_nuevo;

    delete[] datos;
    datos = crec;
    n_alumni++;

    cout << "Alumno agregado.";
}

//funcion 4
int Calcular_Promedio_Estudiante ( Dato * datos , unsigned int id_alumno , char * asignatura_a_buscar ) {
    for (unsigned int i = 0; i < n_alumni; ++i) {
        if (datos[i].Id == id_alumno && strcmp(datos[i].Curso, asignatura_a_buscar) == 0) {
            int suma = datos[i].Notas[0] + datos[i].Notas[1] + datos[i].Notas[2];
            return suma / 3; 
        }
    }
    return -1; 
}


void Menú(){
    cout << 
        "1) Agregar un alumno.\n" <<
        "2) Obtener promedio de un estudiante.\n" << 
        "3) Obtener por evaluación de una asignatura.\n" <<
        "4) Obtener los cursos en los que está inscrito un estudiante.\n" <<
        "5) Obtener los reprobados de un curso con cierto VTR.\n" <<
        "6) Generar informe por cursos.\n" <<
        "0) Salir del programa.\n" <<
        "Ingrese su opción: ";  
}

//funcion 5

int* Calcular_Promedio_Asignatura(Dato* datos , int cantidad_datos , const char* asignatura_a_buscar){
    int suma[3] = {0,0,0};
    int alumnosValidos = 0;
    //recorrer todos los datos de los estudiantes
    for(int i = 0; i < cantidad_datos; i++) {
        string cursoActual(datos[i].Curso);
        if (cursoActual == asignatura_a_buscar){
            suma[0] += datos[i].Notas[0];
            suma[1] += datos[i].Notas[1];
            suma[2] += datos[i].Notas[2];
            alumnosValidos++;
        }
    }
    if(alumnosValidos == 0) return NULL;

    int* promedios = new int[3];
    promedios[0] = (suma[0] + alumnosValidos/2) / alumnosValidos; //redondeo
    promedios[1] = (suma[1] + alumnosValidos/2) / alumnosValidos;
    promedios[2] = (suma[2] + alumnosValidos/2) / alumnosValidos;
    return promedios;
}

//funcion 6

void Listar_Cursos_Estudiante(Dato* datos , int cantidad_datos , unsigned int id_alumno){
    bool encontrado = false; //para ver si se encontro al estudiante
    for (int i = 0; i < cantidad_datos; i++) {
        if (datos[i].Id == id_alumno) {
            if (!encontrado) {
                cout << "Las asignaturas inscritas por el estudiante son: ";
                encontrado = true; // se marca que encontro al estudiant
            }
            cout << datos[i].Curso << " ";
        }
    }
    if (!encontrado) {
        cout << "No existe registro para el estudiante con Id " << id_alumno << ".";
    }
    cout << endl;
}

//funcion 7

int* Listar_Reprobados_VTR(Dato* datos, int cantidad_datos, unsigned short VTR_a_buscar, const char* asignatura_a_buscar) {
    string cursoBuscado(asignatura_a_buscar);
    int* ids_temp = new int[cantidad_datos]; //arerglo temporal para las id de los repobrados
    int contador = 0; //contador reprobados

    //se recorren todos los alum
    for (int i = 0; i < cantidad_datos; i++) {
        string cursoActual(datos[i].Curso);
        if (cursoActual == cursoBuscado && datos[i].VTR == VTR_a_buscar) {
            int promedio = (datos[i].Notas[0] + datos[i].Notas[1] + datos[i].Notas[2] + 1) / 3;
            if (promedio < 55) {
                ids_temp[contador] = datos[i].Id;
                contador++;
            }
        }
    }
    //arreglo final a retonar
    int* resultado = new int[contador + 1];
    resultado[0] = contador;
    for (int i = 0; i < contador; i++) {
        resultado[i + 1] = ids_temp[i];
    }
    delete[] ids_temp;
    return resultado;
}

//funcion 8

void Generar_Informe(Dato* datos, int cantidad_datos) {
    // guardar cursos unicos
    std::string* cursos = new std::string[cantidad_datos];
    int cursosCount = 0;

    for (int i = 0; i < cantidad_datos; i++) {
        std::string cursoActual(datos[i].Curso);
        bool existe = false;
        for (int j = 0; j < cursosCount; j++) {
            if (cursos[j] == cursoActual) {
                existe = true; 
            }
        }
        if (!existe) {
            cursos[cursosCount] = cursoActual;
            cursosCount++;
        }
    }

    // procesar cada curso
    for (int c = 0; c < cursosCount; c++) {
        std::string curso = cursos[c];
        std::ofstream archivo(curso + ".txt");

        if (archivo.is_open()) {
            int cantidad = 0, aprobados = 0, reprobados = 0;
            int maxNotas[3] = {0,0,0};
            int minNotas[3] = {100,100,100};
            int vtr3_reprobados = 0;

            int* ids_vtr3 = new int[cantidad_datos];
            int idsCount = 0;

            // recorrer los alumnos del curso
            for (int i = 0; i < cantidad_datos; i++) {
                std::string cursoActual(datos[i].Curso);
                if (cursoActual == curso) {
                    cantidad++;
                    int promedio = (datos[i].Notas[0] + datos[i].Notas[1] + datos[i].Notas[2] + 1) / 3;

                    archivo << datos[i].Id << " "
                            << datos[i].Nombre << " "
                            << datos[i].Curso << " "
                            << datos[i].Fecha_Nacimiento << " "
                            << datos[i].VTR << " "
                            << datos[i].Notas[0] << " "
                            << datos[i].Notas[1] << " "
                            << datos[i].Notas[2] << " "
                            << promedio << std::endl;

                    if (promedio >= 55) {
                        aprobados++;
                    } else {
                        reprobados++;
                    }

                    for (int n = 0; n < 3; n++) {
                        if (datos[i].Notas[n] > maxNotas[n]) {
                            maxNotas[n] = datos[i].Notas[n];
                        }
                        if (datos[i].Notas[n] < minNotas[n]) {
                            minNotas[n] = datos[i].Notas[n];
                        }
                    }

                    if (datos[i].VTR == 3 && promedio < 55) {
                        ids_vtr3[idsCount] = datos[i].Id;
                        idsCount++;
                        vtr3_reprobados++;
                    }
                }
            }

            archivo << cantidad << std::endl;
            archivo << "Aprobados: " << aprobados << std::endl;
            archivo << "Reprobados: " << reprobados << std::endl;

            int porcentaje = 0;
            if (cantidad > 0) {
                porcentaje = (aprobados * 100) / cantidad;
            }
            archivo << "Porcentaje de aprobacion: " << porcentaje << "%" << std::endl;

            archivo << "Maximos: " << maxNotas[0] << " " << maxNotas[1] << " " << maxNotas[2] << std::endl;
            archivo << "Minimos: " << minNotas[0] << " " << minNotas[1] << " " << minNotas[2] << std::endl;

            archivo << "VTR3 reprobados: " << vtr3_reprobados << std::endl;
            archivo << "Ids: ";
            for (int k = 0; k < idsCount; k++) {
                archivo << ids_vtr3[k] << " ";
            }
            archivo << std::endl;

            archivo.close();
            delete[] ids_vtr3;
        }
    }

    delete[] cursos;
}



int main() {
    string nombre_archivo;
    cout << "Ingrese nombre del archivo binario: ";
    getline(cin, nombre_archivo);
    if (nombre_archivo.empty()) nombre_archivo = "datos.bin";

    Dato* datos = Leer_Archivo(nombre_archivo);
    if (datos == nullptr) {
        cout << "No se pudo continuar sin datos.\n";
        return 1;
    }

    
    n_alumni = Eliminar_Duplicados(datos, (int)n_alumni);

    int opcion = -1;
    while (true) {
        Menú();  
        if (!(cin >> opcion)) {
            cout << "Entrada invalida.\n";
            return 1; 
        }
        cin.ignore(1000, '\n'); 

        if (opcion == 1) {
            Dato nuevo;
            Agregar_Alumno(datos, nuevo);
            cout << "\nTotal de alumnos ahora: " << n_alumni << "\n\n";
        }
        else if (opcion == 2) {
            unsigned int id;
            char sigla[7];

            cout << "ID del alumno: ";
            if (!(cin >> id)) {
                cout << "ID invalido.\n";
                return 1;
            }
            cin.ignore(1000, '\n');

            cout << "Sigla del curso (ej: INF134): ";
            cin.getline(sigla, 7);

            int prom = Calcular_Promedio_Estudiante(datos, id, sigla);
            if (prom == -1) {
                cout << "No se encontro el alumno/curso indicado.\n\n";
            } else {
                cout << "Promedio del estudiante en " << sigla << ": " << prom << "\n\n";
            }
        }
        else if (opcion == 3) {
            char sigla[7];
            cout << "Ingrese la asignatura a calcular el promedio por evaluacion: ";
            cin.getline(sigla, 7);

            int* promedios = Calcular_Promedio_Asignatura(datos, n_alumni, sigla);
            if (promedios == NULL) {
                cout << "No existe el curso " << sigla << ".\n\n";
            } else {
                cout << "El promedio por evaluacion de la asignatura " << sigla
                     << " es: " << promedios[0] << " " << promedios[1] << " " << promedios[2] << "\n\n";
                delete[] promedios; // liberar memoria
            }
        }
        else if (opcion == 4) {
            unsigned int id;
            cout << "Ingrese el Id del alumno a buscar: ";
            cin >> id;
            cin.ignore(1000, '\n');

            Listar_Cursos_Estudiante(datos, n_alumni, id);
            cout << "\n";
        }
        else if (opcion == 5) {
            unsigned short vtr;
            char sigla[7];

            cout << "Ingrese el VTR: ";
            cin >> vtr;
            cin.ignore(1000, '\n');

            cout << "Ingrese el curso: ";
            cin.getline(sigla, 7);

            int* resultado = Listar_Reprobados_VTR(datos, n_alumni, vtr, sigla);
            int cantidad = resultado[0];
            cout << "Cantidad de reprobados: " << cantidad << "\nIds: ";
            for (int i = 0; i < cantidad; i++) {
                cout << resultado[i + 1] << " ";
            }
            cout << "\n\n";
            delete[] resultado; // liberar memoria
        }
        else if (opcion == 6) {
            Generar_Informe(datos, n_alumni);
            cout << "Archivos de informe generados por curso.\n\n";
        }
        else if (opcion == 0) {
            cout << "Saliendo...\n";
            break;
        }
        else {
            cout << "Opcion invalida.\n\n";
        }
    }

    delete[] datos;
    return 0;
}
